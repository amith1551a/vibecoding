
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, Clock, User, Mail, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface MeetingLink {
  id: string;
  title: string;
  description: string;
  duration: number;
  slug: string;
  is_active: boolean;
  user_id: string;
}

interface TimeSlot {
  id: string;
  slot_date: string;
  slot_time: string;
  is_available: boolean;
}

const BookingPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const [meetingLink, setMeetingLink] = useState<MeetingLink | null>(null);
  const [availableSlots, setAvailableSlots] = useState<TimeSlot[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);
  const [bookerInfo, setBookerInfo] = useState({ name: '', email: '' });
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);
  const [booked, setBooked] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedMeetingLink, setGeneratedMeetingLink] = useState<string>('');
  const [emailSent, setEmailSent] = useState<boolean | null>(null);

  useEffect(() => {
    if (slug) {
      fetchMeetingLinkAndSlots();
    }
  }, [slug]);

  const fetchMeetingLinkAndSlots = async () => {
    console.log('=== Fetching meeting link and slots for slug:', slug);
    setError(null);
    setLoading(true);
    
    try {
      // Fetch meeting link
      console.log('Step 1: Fetching meeting link...');
      const { data: meetingLinks, error: linkError } = await supabase
        .from('meeting_links')
        .select('*')
        .eq('slug', slug)
        .eq('is_active', true);

      console.log('Meeting link query result:', { meetingLinks, linkError });

      if (linkError) {
        console.error('Error fetching meeting link:', linkError);
        setError('Failed to load meeting link');
        return;
      }

      if (!meetingLinks || meetingLinks.length === 0) {
        console.log('No active meeting link found for slug:', slug);
        setError('Meeting link not found or inactive');
        return;
      }

      const foundLink = meetingLinks[0];
      console.log('Found meeting link:', foundLink);
      setMeetingLink(foundLink);

      // Fetch available time slots
      console.log('Step 2: Fetching time slots for meeting link ID:', foundLink.id);
      const { data: timeSlots, error: slotsError } = await supabase
        .from('time_slots')
        .select('*')
        .eq('meeting_link_id', foundLink.id)
        .eq('is_available', true)
        .gte('slot_date', new Date().toISOString().split('T')[0]) // Only future dates
        .order('slot_date', { ascending: true })
        .order('slot_time', { ascending: true });

      console.log('Time slots query result:', { timeSlots, slotsError });

      if (slotsError) {
        console.error('Error fetching time slots:', slotsError);
        setError('Failed to load available time slots');
        return;
      }

      console.log('Setting available slots:', timeSlots?.length || 0, 'slots found');
      setAvailableSlots(timeSlots || []);

    } catch (error) {
      console.error('Unexpected error:', error);
      setError('An unexpected error occurred');
    } finally {
      console.log('=== Finished fetching, setting loading to false');
      setLoading(false);
    }
  };

  const generateMeetingLink = () => {
    // Generate a unique meeting room ID
    const roomId = `${meetingLink?.slug}-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
    // Use a video conferencing link (you can customize this to your preferred platform)
    return `https://meet.jit.si/${roomId}`;
  };

  const handleBooking = async () => {
    if (!selectedSlot || !meetingLink) return;

    setBooking(true);
    try {
      console.log('Creating booking for slot:', selectedSlot);

      // Generate meeting link
      const meetLink = generateMeetingLink();
      setGeneratedMeetingLink(meetLink);

      // Create booking
      const { error: bookingError } = await supabase
        .from('bookings')
        .insert({
          meeting_link_id: meetingLink.id,
          booker_name: bookerInfo.name,
          booker_email: bookerInfo.email,
          booking_date: selectedSlot.slot_date,
          booking_time: selectedSlot.slot_time,
          status: 'confirmed',
        });

      if (bookingError) throw bookingError;

      // Mark time slot as unavailable
      const { error: slotError } = await supabase
        .from('time_slots')
        .update({ is_available: false })
        .eq('id', selectedSlot.id);

      if (slotError) throw slotError;

      // Send confirmation email
      let emailSuccess = false;
      try {
        const { data: emailData, error: emailError } = await supabase.functions.invoke('send-booking-confirmation', {
          body: {
            bookerName: bookerInfo.name,
            bookerEmail: bookerInfo.email,
            meetingTitle: meetingLink.title,
            meetingDate: selectedSlot.slot_date,
            meetingTime: selectedSlot.slot_time,
            duration: meetingLink.duration,
            meetingLink: meetLink,
          }
        });

        if (emailError) {
          console.error('Error calling email function:', emailError);
          emailSuccess = false;
        } else if (emailData?.success === false || emailData?.emailSent === false) {
          console.error('Email sending failed:', emailData?.error);
          emailSuccess = false;
        } else {
          console.log('Confirmation email sent successfully:', emailData);
          emailSuccess = true;
        }
      } catch (emailErr) {
        console.error('Email sending failed:', emailErr);
        emailSuccess = false;
      }

      setEmailSent(emailSuccess);
      setBooked(true);
      
      if (emailSuccess) {
        toast.success('Meeting booked successfully! Confirmation email sent.');
      } else {
        toast.success('Meeting booked successfully!');
        toast.warning('Could not send confirmation email. Please save your meeting link.');
      }
    } catch (error) {
      console.error('Error booking meeting:', error);
      toast.error('Failed to book meeting');
    } finally {
      setBooking(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    const time = new Date();
    time.setHours(parseInt(hours), parseInt(minutes));
    return time.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  console.log('=== Render state ===');
  console.log('Loading:', loading);
  console.log('Meeting link:', meetingLink);
  console.log('Available slots:', availableSlots.length);
  console.log('Error:', error);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading meeting details...</p>
          <p className="mt-2 text-sm text-gray-500">Slug: {slug}</p>
        </div>
      </div>
    );
  }

  if (error || !meetingLink) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-8">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              {error || 'Meeting Link Not Found'}
            </h2>
            <p className="text-gray-600">
              {error ? 'Please try again or contact support.' : "The meeting link you're looking for doesn't exist or has been disabled."}
            </p>
            <p className="text-sm text-gray-500 mt-2">Slug: {slug}</p>
            <Button 
              onClick={() => window.location.reload()} 
              variant="outline" 
              className="mt-4"
            >
              Reload Page
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (booked) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-8">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Meeting Booked!</h2>
            <p className="text-gray-600 mb-4">
              Your meeting has been successfully scheduled for{' '}
              <strong>{formatDate(selectedSlot!.slot_date)}</strong> at{' '}
              <strong>{formatTime(selectedSlot!.slot_time)}</strong>
            </p>
            
            {generatedMeetingLink && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                <p className="text-sm font-semibold text-green-800 mb-2">Your Meeting Link:</p>
                <a 
                  href={generatedMeetingLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 underline break-all text-sm"
                >
                  {generatedMeetingLink}
                </a>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedMeetingLink);
                    toast.success('Meeting link copied to clipboard!');
                  }}
                  className="mt-3 w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors text-sm font-medium"
                >
                  Copy Meeting Link
                </button>
              </div>
            )}
            
            {emailSent ? (
              <div className="bg-blue-50 border border-blue-200 rounded p-3 text-sm text-blue-800">
                A confirmation email has been sent to <strong>{bookerInfo.email}</strong>
              </div>
            ) : (
              <div className="bg-amber-50 border border-amber-200 rounded p-3 text-sm text-amber-800">
                <strong>Note:</strong> We couldn't send a confirmation email. Please save the meeting link above for your records.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  const groupedSlots = availableSlots.reduce((groups: { [key: string]: TimeSlot[] }, slot) => {
    if (!groups[slot.slot_date]) {
      groups[slot.slot_date] = [];
    }
    groups[slot.slot_date].push(slot);
    return groups;
  }, {});

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Meeting Info */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Calendar className="h-6 w-6 text-blue-600" />
                  <CardTitle className="text-xl">{meetingLink.title}</CardTitle>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {meetingLink.duration} minutes
                  </div>
                </div>
              </CardHeader>
              {meetingLink.description && (
                <CardContent>
                  <p className="text-gray-700">{meetingLink.description}</p>
                </CardContent>
              )}
            </Card>

            {selectedSlot && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Selected Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-3 p-3 bg-blue-50 border border-blue-200 rounded">
                    <Calendar className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium text-gray-900">
                        {formatDate(selectedSlot.slot_date)}
                      </p>
                      <p className="text-sm text-gray-600">
                        {formatTime(selectedSlot.slot_time)} ({meetingLink.duration} min)
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Booking Form */}
          <div className="space-y-6">
            {!selectedSlot ? (
              <Card>
                <CardHeader>
                  <CardTitle>Select a Time</CardTitle>
                  <CardDescription>Choose from available time slots</CardDescription>
                </CardHeader>
                <CardContent className="max-h-96 overflow-y-auto">
                  {Object.keys(groupedSlots).length === 0 ? (
                    <div className="text-center py-8">
                      <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No available time slots</p>
                      <p className="text-sm text-gray-500 mt-2">
                        All slots may be booked or no slots have been configured yet.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {Object.entries(groupedSlots).map(([date, slots]) => (
                        <div key={date}>
                          <h3 className="font-medium text-gray-900 mb-2">
                            {formatDate(date)}
                          </h3>
                          <div className="grid grid-cols-3 gap-2">
                            {slots.map((slot) => (
                              <Button
                                key={slot.id}
                                variant="outline"
                                size="sm"
                                onClick={() => setSelectedSlot(slot)}
                                className="text-xs"
                              >
                                {formatTime(slot.slot_time)}
                              </Button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Book Your Meeting</CardTitle>
                  <CardDescription>Enter your details to confirm the booking</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="booker-name">Full Name</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="booker-name"
                        value={bookerInfo.name}
                        onChange={(e) => setBookerInfo({ ...bookerInfo, name: e.target.value })}
                        placeholder="Enter your full name"
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="booker-email">Email Address</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="booker-email"
                        type="email"
                        value={bookerInfo.email}
                        onChange={(e) => setBookerInfo({ ...bookerInfo, email: e.target.value })}
                        placeholder="Enter your email"
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button
                      variant="outline"
                      onClick={() => setSelectedSlot(null)}
                      className="flex-1"
                    >
                      Back
                    </Button>
                    <Button
                      onClick={handleBooking}
                      disabled={booking || !bookerInfo.name || !bookerInfo.email}
                      className="flex-1"
                    >
                      {booking ? 'Booking...' : 'Confirm Booking'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;
