
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface CreateMeetingLinkDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
}

interface AvailabilitySlot {
  day: number;
  startTime: string;
  endTime: string;
}

const CreateMeetingLinkDialog: React.FC<CreateMeetingLinkDialogProps> = ({
  open,
  onOpenChange,
  onCreated,
}) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    duration: '30',
    slug: '',
  });
  
  const [availability, setAvailability] = useState<AvailabilitySlot[]>([]);
  const [selectedDays, setSelectedDays] = useState<number[]>([]);

  const days = [
    { value: 1, label: 'Monday' },
    { value: 2, label: 'Tuesday' },
    { value: 3, label: 'Wednesday' },
    { value: 4, label: 'Thursday' },
    { value: 5, label: 'Friday' },
    { value: 6, label: 'Saturday' },
    { value: 0, label: 'Sunday' },
  ];

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00'
  ];

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  };

  const handleTitleChange = (title: string) => {
    setFormData({
      ...formData,
      title,
      slug: formData.slug || generateSlug(title),
    });
  };

  const handleDayToggle = (day: number, checked: boolean) => {
    if (checked) {
      setSelectedDays([...selectedDays, day]);
      setAvailability([
        ...availability,
        { day, startTime: '09:00', endTime: '17:00' }
      ]);
    } else {
      setSelectedDays(selectedDays.filter(d => d !== day));
      setAvailability(availability.filter(slot => slot.day !== day));
    }
  };

  const updateAvailabilitySlot = (day: number, field: 'startTime' | 'endTime', value: string) => {
    setAvailability(availability.map(slot => 
      slot.day === day ? { ...slot, [field]: value } : slot
    ));
  };

  const generateTimeSlots = (meetingLinkId: string, duration: number) => {
    const slots = [];
    const today = new Date();
    const endDate = new Date();
    endDate.setDate(today.getDate() + 365); // Generate slots for next year

    console.log('Generating time slots for duration:', duration, 'minutes');

    for (let date = new Date(today); date <= endDate; date.setDate(date.getDate() + 1)) {
      const dayOfWeek = date.getDay();
      const daySlots = availability.filter(slot => slot.day === dayOfWeek);

      for (const availSlot of daySlots) {
        const startTime = new Date(`1970-01-01T${availSlot.startTime}`);
        const endTime = new Date(`1970-01-01T${availSlot.endTime}`);

        for (let time = new Date(startTime); time < endTime; time.setMinutes(time.getMinutes() + duration)) {
          const timeString = time.toTimeString().slice(0, 5);
          const dateString = date.toISOString().split('T')[0];
          
          // Skip past dates
          const slotDateTime = new Date(`${dateString}T${timeString}`);
          if (slotDateTime <= new Date()) continue;

          slots.push({
            meeting_link_id: meetingLinkId,
            slot_date: dateString,
            slot_time: timeString,
            is_available: true,
          });
        }
      }
    }

    console.log('Generated', slots.length, 'time slots');
    return slots;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (availability.length === 0) {
      toast.error('Please select at least one day for availability');
      return;
    }

    setLoading(true);
    
    try {
      console.log('Creating meeting link...');
      
      // Create meeting link
      const { data: meetingLink, error: linkError } = await supabase
        .from('meeting_links')
        .insert({
          title: formData.title,
          description: formData.description,
          duration: parseInt(formData.duration),
          slug: formData.slug,
          user_id: (await supabase.auth.getUser()).data.user?.id,
        })
        .select()
        .single();

      if (linkError) throw linkError;
      console.log('Meeting link created:', meetingLink);

      // Create availability slots
      const availabilitySlots = availability.map(slot => ({
        meeting_link_id: meetingLink.id,
        day_of_week: slot.day,
        start_time: slot.startTime,
        end_time: slot.endTime,
      }));

      const { error: slotsError } = await supabase
        .from('availability_slots')
        .insert(availabilitySlots);

      if (slotsError) throw slotsError;
      console.log('Availability slots created');

      // Generate and store time slots
      const timeSlots = generateTimeSlots(meetingLink.id, parseInt(formData.duration));
      
      if (timeSlots.length > 0) {
        const { error: timeSlotsError } = await supabase
          .from('time_slots')
          .insert(timeSlots);

        if (timeSlotsError) throw timeSlotsError;
        console.log('Time slots created');
      }

      toast.success('Meeting link created successfully with all time slots!');
      onCreated();
      
      // Reset form
      setFormData({ title: '', description: '', duration: '30', slug: '' });
      setAvailability([]);
      setSelectedDays([]);
      
    } catch (error) {
      console.error('Error creating meeting link:', error);
      toast.error('Failed to create meeting link');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Meeting Link</DialogTitle>
          <DialogDescription>
            Set up a new scheduling link with your availability
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Meeting Details</h3>
            
            <div>
              <Label htmlFor="title">Meeting Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                placeholder="e.g., 30 min consultation"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief description of the meeting"
                rows={3}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="duration">Duration</Label>
                <Select value={formData.duration} onValueChange={(value) => setFormData({ ...formData, duration: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="45">45 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="90">1.5 hours</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="slug">URL Slug</Label>
                <Input
                  id="slug"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  placeholder="meeting-slug"
                  required
                />
              </div>
            </div>
          </div>

          {/* Availability */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Availability</h3>
            <p className="text-sm text-gray-600">Select the days and times when you're available</p>
            
            <div className="space-y-3">
              {days.map((day) => (
                <div key={day.value} className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2 w-24">
                    <Checkbox
                      id={`day-${day.value}`}
                      checked={selectedDays.includes(day.value)}
                      onCheckedChange={(checked) => handleDayToggle(day.value, checked as boolean)}
                    />
                    <Label htmlFor={`day-${day.value}`} className="text-sm font-medium">
                      {day.label}
                    </Label>
                  </div>
                  
                  {selectedDays.includes(day.value) && (
                    <div className="flex items-center space-x-2 flex-1">
                      <Select
                        value={availability.find(slot => slot.day === day.value)?.startTime || '09:00'}
                        onValueChange={(value) => updateAvailabilitySlot(day.value, 'startTime', value)}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {timeSlots.map(time => (
                            <SelectItem key={time} value={time}>{time}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      
                      <span className="text-sm text-gray-500">to</span>
                      
                      <Select
                        value={availability.find(slot => slot.day === day.value)?.endTime || '17:00'}
                        onValueChange={(value) => updateAvailabilitySlot(day.value, 'endTime', value)}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {timeSlots.map(time => (
                            <SelectItem key={time} value={time}>{time}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Creating...' : 'Create Meeting Link'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateMeetingLinkDialog;
