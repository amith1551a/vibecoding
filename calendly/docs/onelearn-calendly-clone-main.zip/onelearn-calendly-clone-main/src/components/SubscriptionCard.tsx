
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Crown, Zap, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SubscriptionCardProps {
  currentPlan: string;
  onUpgradeSuccess?: () => void;
}

const SubscriptionCard: React.FC<SubscriptionCardProps> = ({ currentPlan, onUpgradeSuccess }) => {
  const [isLoading, setIsLoading] = useState<string | null>(null);

  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: '$0',
      period: 'forever',
      features: ['1 Meeting Link', 'Basic Scheduling', 'Email Notifications'],
      maxLinks: 1,
      icon: null,
    },
    {
      id: 'pro',
      name: 'Pro',
      price: '$9.99',
      period: 'month',
      features: ['3 Meeting Links', 'Custom Branding', 'Advanced Analytics', 'Priority Support'],
      maxLinks: 3,
      icon: <Crown className="h-4 w-4" />,
    },
    {
      id: 'pro_plus',
      name: 'Pro Plus',
      price: '$19.99',
      period: 'month',
      features: ['5 Meeting Links', 'Team Collaboration', 'API Access', 'White Label', '24/7 Support'],
      maxLinks: 5,
      icon: <Zap className="h-4 w-4" />,
    },
  ];

  const getButtonText = (planId: string) => {
    if (planId === currentPlan) return 'Current Plan';
    if (planId === 'free' && currentPlan !== 'free') return 'Switch to Free';
    return `Upgrade to ${planId === 'pro' ? 'Pro' : 'Pro Plus'}`;
  };

  const handlePlanChange = async (planId: string) => {
    if (planId === currentPlan) return;

    setIsLoading(planId);

    try {
      if (planId === 'free') {
        // Cancel subscription to switch to free
        console.log('Cancelling subscription to switch to Free plan');
        const { data, error } = await supabase.functions.invoke('calendly_cancel_subscription');

        if (error) {
          console.error('Error cancelling subscription:', error);
          throw error;
        }

        console.log('Cancellation response:', data);
        
        if (data?.success) {
          toast.success('Subscription cancelled! You are now on the Free plan.');
          // Force refresh subscription status
          if (onUpgradeSuccess) {
            onUpgradeSuccess();
          }
        } else {
          throw new Error(data?.error || 'Failed to cancel subscription');
        }
      } else {
        // Upgrade to paid plan
        console.log('Creating checkout for plan:', planId);
        const { data, error } = await supabase.functions.invoke('calendly_create_checkout', {
          body: { planType: planId }
        });

        if (error) {
          console.error('Error creating checkout:', error);
          throw error;
        }

        console.log('Checkout response:', data);
        
        if (data?.url) {
          window.location.href = data.url;
        } else {
          throw new Error('No checkout URL received');
        }
      }
    } catch (error) {
      console.error('Error changing plan:', error);
      toast.error('Failed to change plan. Please try again.');
    } finally {
      setIsLoading(null);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Subscription Plans</CardTitle>
        <CardDescription>Choose the plan that fits your needs</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`border rounded-lg p-4 ${
              currentPlan === plan.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {plan.icon}
                <h3 className="font-semibold text-gray-900">{plan.name}</h3>
                {currentPlan === plan.id && (
                  <Badge variant="default" className="text-xs">Current</Badge>
                )}
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-gray-900">{plan.price}</span>
                <span className="text-sm text-gray-600">/{plan.period}</span>
              </div>
            </div>
            
            <ul className="space-y-2 mb-4">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-center gap-2 text-sm text-gray-600">
                  <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>
            
            <Button
              className="w-full"
              variant={currentPlan === plan.id ? "outline" : plan.id === 'free' ? "secondary" : "default"}
              disabled={currentPlan === plan.id || isLoading !== null}
              onClick={() => handlePlanChange(plan.id)}
            >
              {isLoading === plan.id ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                getButtonText(plan.id)
              )}
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default SubscriptionCard;
