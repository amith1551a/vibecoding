import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Plus, ExternalLink, Calendar, Clock, Users, LogOut, Crown, RefreshCw, Settings } from 'lucide-react';
import { toast } from 'sonner';
import CreateMeetingLinkDialog from './CreateMeetingLinkDialog';
import SubscriptionCard from './SubscriptionCard';
import BookingsSidebar from './BookingsSidebar';

interface MeetingLink {
  id: string;
  title: string;
  description: string;
  duration: number;
  slug: string;
  is_active: boolean;
  created_at: string;
}

interface UserPlan {
  plan: string;
  max_links: number;
}

const Dashboard = () => {
  const { user, signOut, checkSubscription } = useAuth();
  const [meetingLinks, setMeetingLinks] = useState<MeetingLink[]>([]);
  const [userPlan, setUserPlan] = useState<UserPlan>({ plan: 'free', max_links: 1 });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  const fetchMeetingLinks = async () => {
    if (!user) return;
    
    try {
      console.log('Fetching meeting links for user:', user.id);
      const { data: linksData, error: linksError } = await supabase
        .from('meeting_links')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (linksError) {
        console.error('Error fetching meeting links:', linksError);
        throw linksError;
      }
      
      console.log('Fetched meeting links:', linksData);
      setMeetingLinks(linksData || []);
    } catch (error) {
      console.error('Error fetching meeting links:', error);
      toast.error('Failed to load meeting links');
    }
  };

  const updateSubscriptionStatus = async () => {
    if (!user) return;
    
    try {
      console.log('Checking subscription via calendly_check_subscription...');
      const { data, error } = await supabase.functions.invoke('calendly_check_subscription');
      
      if (error) {
        console.error('Error checking subscription:', error);
        throw error;
      }
      
      console.log('Subscription check result:', data);
      
      if (data?.subscriptionTier === 'pro') {
        setUserPlan({ plan: 'pro', max_links: 3 });
      } else if (data?.subscriptionTier === 'pro_plus') {
        setUserPlan({ plan: 'pro_plus', max_links: 5 });
      } else {
        setUserPlan({ plan: 'free', max_links: 1 });
      }
    } catch (error) {
      console.error('Error checking subscription:', error);
      setUserPlan({ plan: 'free', max_links: 1 });
    }
  };

  const fetchData = async () => {
    if (!user) return;
    
    await Promise.all([
      fetchMeetingLinks(),
      updateSubscriptionStatus()
    ]);
  };

  useEffect(() => {
    if (user) {
      fetchData().finally(() => {
        setLoading(false);
      });
    }
  }, [user?.id]);

  // Check for URL parameters that might indicate returning from Stripe
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('success');
    const sessionId = urlParams.get('session_id');
    
    if (success === 'true' || sessionId) {
      console.log('Detected return from Stripe, refreshing data...');
      handleRefresh();
      
      // Clean up URL parameters
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const handleRefresh = async () => {
    if (!user) return;
    
    setRefreshing(true);
    try {
      // Check subscription first via calendly edge function
      await updateSubscriptionStatus();
      // Then fetch meeting links
      await fetchMeetingLinks();
      toast.success('Data refreshed successfully');
    } catch (error) {
      console.error('Error refreshing data:', error);
      toast.error('Failed to refresh data');
    } finally {
      setRefreshing(false);
    }
  };

  const getPlanBadge = (plan: string) => {
    switch (plan) {
      case 'pro':
        return <Badge variant="secondary" className="bg-blue-100 text-blue-800"><Crown className="w-3 h-3 mr-1" />Pro</Badge>;
      case 'pro_plus':
        return <Badge variant="secondary" className="bg-purple-100 text-purple-800"><Crown className="w-3 h-3 mr-1" />Pro Plus</Badge>;
      default:
        return <Badge variant="outline">Free</Badge>;
    }
  };

  const canCreateMoreLinks = meetingLinks.length < userPlan.max_links;
  const linksRemaining = Math.max(0, userPlan.max_links - meetingLinks.length);

  const handleManageSubscription = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('calendly_customer_portal');
      
      if (error) {
        console.error('Error opening customer portal:', error);
        toast.error('Failed to open subscription management. Please try again.');
        return;
      }
      
      if (data?.url) {
        window.location.href = data.url;
      } else {
        toast.error('Could not open subscription portal. You may not have an active subscription.');
      }
    } catch (error) {
      console.error('Error opening customer portal:', error);
      toast.error('Failed to open subscription management.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <Calendar className="h-8 w-8 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-900">MeetScheduler</h1>
            </div>
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRefresh}
                disabled={refreshing}
                className="flex items-center gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <span className="text-sm text-gray-600">Welcome, {user?.user_metadata?.full_name || user?.email}</span>
              {getPlanBadge(userPlan.plan)}
              {userPlan.plan !== 'free' && (
                <Button variant="outline" size="sm" onClick={handleManageSubscription}>
                  <Settings className="h-4 w-4 mr-2" />
                  Manage Subscription
                </Button>
              )}
              <Button variant="ghost" size="sm" onClick={signOut}>
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-blue-100 rounded-lg">
                      <Calendar className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{meetingLinks.length}</p>
                      <p className="text-sm text-gray-600">Meeting Links</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-green-100 rounded-lg">
                      <Clock className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{meetingLinks.filter(link => link.is_active).length}</p>
                      <p className="text-sm text-gray-600">Active Links</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-purple-100 rounded-lg">
                      <Users className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{linksRemaining}</p>
                      <p className="text-sm text-gray-600">Links Remaining</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Meeting Links */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Your Meeting Links</CardTitle>
                    <CardDescription>Manage your scheduling links</CardDescription>
                  </div>
                  <Button 
                    onClick={() => setShowCreateDialog(true)}
                    disabled={!canCreateMoreLinks}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create Link
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {meetingLinks.length === 0 ? (
                  <div className="text-center py-8">
                    <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No meeting links yet</h3>
                    <p className="text-gray-600 mb-4">Create your first scheduling link to get started</p>
                    <Button onClick={() => setShowCreateDialog(true)} disabled={!canCreateMoreLinks}>
                      <Plus className="h-4 w-4 mr-2" />
                      Create Your First Link
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {meetingLinks.map((link) => (
                      <div key={link.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-gray-900">{link.title}</h3>
                              <Badge variant={link.is_active ? "default" : "secondary"}>
                                {link.is_active ? "Active" : "Inactive"}
                              </Badge>
                            </div>
                            {link.description && (
                              <p className="text-gray-600 text-sm mb-2">{link.description}</p>
                            )}
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <span className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                {link.duration} min
                              </span>
                              <span className="font-mono bg-gray-100 px-2 py-1 rounded">
                                /{link.slug}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => window.open(`/book/${link.slug}`, '_blank')}
                            >
                              <ExternalLink className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {!canCreateMoreLinks && (
                  <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <p className="text-sm text-amber-800">
                      You've reached your limit of {userPlan.max_links} meeting link{userPlan.max_links > 1 ? 's' : ''}. 
                      Upgrade your plan to create more links.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <SubscriptionCard currentPlan={userPlan.plan} onUpgradeSuccess={handleRefresh} />
            <BookingsSidebar />
          </div>
        </div>
      </div>

      <CreateMeetingLinkDialog 
        open={showCreateDialog}
        onOpenChange={setShowCreateDialog}
        onCreated={() => {
          fetchMeetingLinks();
          setShowCreateDialog(false);
        }}
      />
    </div>
  );
};

export default Dashboard;
