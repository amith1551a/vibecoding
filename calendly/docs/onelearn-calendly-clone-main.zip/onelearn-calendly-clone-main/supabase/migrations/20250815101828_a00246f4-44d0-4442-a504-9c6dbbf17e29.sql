
-- Create time_slots table to store pre-generated time slots
CREATE TABLE public.time_slots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  meeting_link_id UUID NOT NULL REFERENCES public.meeting_links(id) ON DELETE CASCADE,
  slot_date DATE NOT NULL,
  slot_time TIME NOT NULL,
  is_available BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add Row Level Security (RLS)
ALTER TABLE public.time_slots ENABLE ROW LEVEL SECURITY;

-- Allow anyone to view available time slots (for booking page)
CREATE POLICY "Anyone can view available time slots" 
  ON public.time_slots 
  FOR SELECT 
  USING (is_available = true);

-- Allow users to view their own meeting's time slots
CREATE POLICY "Users can view their own meeting time slots" 
  ON public.time_slots 
  FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM public.meeting_links 
    WHERE meeting_links.id = time_slots.meeting_link_id 
    AND meeting_links.user_id = auth.uid()
  ));

-- Allow users to insert time slots for their own meetings
CREATE POLICY "Users can insert their own meeting time slots" 
  ON public.time_slots 
  FOR INSERT 
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.meeting_links 
    WHERE meeting_links.id = time_slots.meeting_link_id 
    AND meeting_links.user_id = auth.uid()
  ));

-- Allow users to update their own meeting time slots
CREATE POLICY "Users can update their own meeting time slots" 
  ON public.time_slots 
  FOR UPDATE 
  USING (EXISTS (
    SELECT 1 FROM public.meeting_links 
    WHERE meeting_links.id = time_slots.meeting_link_id 
    AND meeting_links.user_id = auth.uid()
  ));

-- Allow anyone to update availability (for booking process)
CREATE POLICY "Anyone can mark slots as unavailable" 
  ON public.time_slots 
  FOR UPDATE 
  USING (true)
  WITH CHECK (is_available = false);

-- Create indexes for better performance
CREATE INDEX idx_time_slots_meeting_link_id ON public.time_slots(meeting_link_id);
CREATE INDEX idx_time_slots_date_time ON public.time_slots(slot_date, slot_time);
CREATE INDEX idx_time_slots_available ON public.time_slots(is_available);
