
-- First, let's drop all existing UPDATE policies for time_slots and create a clear one
DROP POLICY IF EXISTS "Anyone can mark slots as unavailable" ON public.time_slots;
DROP POLICY IF EXISTS "Users can update their own meeting time slots" ON public.time_slots;

-- Create a comprehensive UPDATE policy that allows both owners and public booking updates
CREATE POLICY "Allow time slot updates" 
  ON public.time_slots 
  FOR UPDATE 
  USING (
    -- Allow owners to update their own meeting time slots
    EXISTS (
      SELECT 1 FROM meeting_links 
      WHERE meeting_links.id = time_slots.meeting_link_id 
      AND meeting_links.user_id = auth.uid()
    )
    OR 
    -- Allow anyone to mark slots as unavailable (for booking)
    true
  )
  WITH CHECK (
    -- Owners can make any changes to their slots
    (EXISTS (
      SELECT 1 FROM meeting_links 
      WHERE meeting_links.id = time_slots.meeting_link_id 
      AND meeting_links.user_id = auth.uid()
    ))
    OR 
    -- Public users can only mark slots as unavailable
    (is_available = false)
  );
