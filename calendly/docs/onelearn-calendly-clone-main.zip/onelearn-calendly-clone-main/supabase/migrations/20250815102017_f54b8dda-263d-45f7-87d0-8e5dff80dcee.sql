
-- Create the time_slots table to store pre-generated time slots for meeting links
CREATE TABLE public.time_slots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  meeting_link_id UUID REFERENCES public.meeting_links(id) ON DELETE CASCADE NOT NULL,
  slot_date DATE NOT NULL,
  slot_time TIME NOT NULL,
  is_available BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add Row Level Security (RLS)
ALTER TABLE public.time_slots ENABLE ROW LEVEL SECURITY;

-- Create policy for users to view time slots for their meeting links
CREATE POLICY "Users can view time slots for their meeting links" 
  ON public.time_slots 
  FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM public.meeting_links 
    WHERE meeting_links.id = time_slots.meeting_link_id 
    AND meeting_links.user_id = auth.uid()
  ));

-- Create policy for users to insert time slots for their meeting links
CREATE POLICY "Users can create time slots for their meeting links" 
  ON public.time_slots 
  FOR INSERT 
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.meeting_links 
    WHERE meeting_links.id = time_slots.meeting_link_id 
    AND meeting_links.user_id = auth.uid()
  ));

-- Create policy for users to update time slots for their meeting links
CREATE POLICY "Users can update time slots for their meeting links" 
  ON public.time_slots 
  FOR UPDATE 
  USING (EXISTS (
    SELECT 1 FROM public.meeting_links 
    WHERE meeting_links.id = time_slots.meeting_link_id 
    AND meeting_links.user_id = auth.uid()
  ));

-- Create policy for users to delete time slots for their meeting links
CREATE POLICY "Users can delete time slots for their meeting links" 
  ON public.time_slots 
  FOR DELETE 
  USING (EXISTS (
    SELECT 1 FROM public.meeting_links 
    WHERE meeting_links.id = time_slots.meeting_link_id 
    AND meeting_links.user_id = auth.uid()
  ));

-- Allow public to view available time slots for booking (anyone can see available slots)
CREATE POLICY "Anyone can view available time slots for booking" 
  ON public.time_slots 
  FOR SELECT 
  USING (is_available = true);

-- Add index for better performance
CREATE INDEX idx_time_slots_meeting_link_id ON public.time_slots(meeting_link_id);
CREATE INDEX idx_time_slots_date_time ON public.time_slots(slot_date, slot_time);
CREATE INDEX idx_time_slots_available ON public.time_slots(is_available) WHERE is_available = true;
