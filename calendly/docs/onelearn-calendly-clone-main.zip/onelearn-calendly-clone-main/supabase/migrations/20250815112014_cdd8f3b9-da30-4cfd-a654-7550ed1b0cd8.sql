
-- Add policy to allow anyone to view active meeting links for booking
CREATE POLICY "Anyone can view active meeting links for booking" 
  ON public.meeting_links 
  FOR SELECT 
  USING (is_active = true);
