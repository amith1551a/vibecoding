
-- Update the policy to allow anyone to mark time slots as unavailable for booking
DROP POLICY IF EXISTS "Anyone can mark slots as unavailable" ON public.time_slots;

CREATE POLICY "Anyone can mark slots as unavailable" 
  ON public.time_slots 
  FOR UPDATE 
  USING (true)
  WITH CHECK (is_available = false);
