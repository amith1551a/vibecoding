
-- Create meeting_links table for user's scheduling links
CREATE TABLE public.meeting_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  duration INTEGER NOT NULL DEFAULT 30, -- in minutes
  slug TEXT UNIQUE NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create availability_slots table for time slots
CREATE TABLE public.availability_slots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_link_id UUID REFERENCES public.meeting_links(id) ON DELETE CASCADE NOT NULL,
  day_of_week INTEGER NOT NULL, -- 0=Sunday, 1=Monday, etc.
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create bookings table for scheduled meetings
CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_link_id UUID REFERENCES public.meeting_links(id) ON DELETE CASCADE NOT NULL,
  booker_name TEXT NOT NULL,
  booker_email TEXT NOT NULL,
  booking_date DATE NOT NULL,
  booking_time TIME NOT NULL,
  status TEXT DEFAULT 'confirmed',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.meeting_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.availability_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- RLS policies for meeting_links
CREATE POLICY "Users can manage their own meeting links" ON public.meeting_links
  FOR ALL USING (auth.uid() = user_id);

-- RLS policies for availability_slots
CREATE POLICY "Users can manage their own availability slots" ON public.availability_slots
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.meeting_links 
      WHERE id = meeting_link_id AND user_id = auth.uid()
    )
  );

-- RLS policies for bookings
CREATE POLICY "Users can view bookings for their meeting links" ON public.bookings
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.meeting_links 
      WHERE id = meeting_link_id AND user_id = auth.uid()
    )
  );

-- Allow anyone to create bookings (for public booking)
CREATE POLICY "Anyone can create bookings" ON public.bookings
  FOR INSERT WITH CHECK (true);

-- Allow anyone to view bookings for availability checking
CREATE POLICY "Anyone can view bookings for availability" ON public.bookings
  FOR SELECT USING (true);

-- Create indexes for better performance
CREATE INDEX idx_meeting_links_user_id ON public.meeting_links(user_id);
CREATE INDEX idx_meeting_links_slug ON public.meeting_links(slug);
CREATE INDEX idx_availability_slots_meeting_link_id ON public.availability_slots(meeting_link_id);
CREATE INDEX idx_bookings_meeting_link_id ON public.bookings(meeting_link_id);
CREATE INDEX idx_bookings_date_time ON public.bookings(booking_date, booking_time);
