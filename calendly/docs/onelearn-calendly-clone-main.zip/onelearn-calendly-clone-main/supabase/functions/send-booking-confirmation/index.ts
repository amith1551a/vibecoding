
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface BookingEmailRequest {
  bookerName: string;
  bookerEmail: string;
  meetingTitle: string;
  meetingDate: string;
  meetingTime: string;
  duration: number;
  meetingLink: string;
  hostEmail?: string;
}

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[SEND-BOOKING-CONFIRMATION] ${step}${detailsStr}`);
};

serve(async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");
    
    const { 
      bookerName, 
      bookerEmail, 
      meetingTitle, 
      meetingDate, 
      meetingTime, 
      duration,
      meetingLink,
      hostEmail 
    }: BookingEmailRequest = await req.json();

    logStep("Request received", { bookerEmail, meetingTitle, meetingDate, meetingTime });

    // Format date for display
    const formattedDate = new Date(meetingDate).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    // Format time for display
    const [hours, minutes] = meetingTime.split(':');
    const time = new Date();
    time.setHours(parseInt(hours), parseInt(minutes));
    const formattedTime = time.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });

    // Send confirmation email to booker
    const bookerEmailResponse = await resend.emails.send({
      from: "MeetScheduler <onboarding@resend.dev>",
      to: [bookerEmail],
      subject: `Meeting Confirmed: ${meetingTitle}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
            .meeting-details { background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0; }
            .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #f3f4f6; }
            .detail-row:last-child { border-bottom: none; }
            .detail-label { font-weight: 600; color: #6b7280; width: 120px; }
            .detail-value { color: #111827; }
            .meeting-link { background: #3B82F6; color: white !important; padding: 15px 30px; text-decoration: none; border-radius: 8px; display: inline-block; margin: 20px 0; font-weight: 600; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0; font-size: 24px;">✅ Meeting Confirmed!</h1>
            </div>
            <div class="content">
              <p>Hi ${bookerName},</p>
              <p>Your meeting has been successfully scheduled. Here are the details:</p>
              
              <div class="meeting-details">
                <div class="detail-row">
                  <span class="detail-label">Meeting:</span>
                  <span class="detail-value">${meetingTitle}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Date:</span>
                  <span class="detail-value">${formattedDate}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Time:</span>
                  <span class="detail-value">${formattedTime}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Duration:</span>
                  <span class="detail-value">${duration} minutes</span>
                </div>
              </div>

              <div style="text-align: center;">
                <p style="font-weight: 600; margin-bottom: 10px;">Your Meeting Link:</p>
                <a href="${meetingLink}" class="meeting-link">Join Meeting</a>
                <p style="color: #6b7280; font-size: 14px; word-break: break-all;">${meetingLink}</p>
              </div>

              <p style="margin-top: 30px;">Please save this email for your records. You can use the meeting link above to join the meeting at the scheduled time.</p>
              
              <div class="footer">
                <p>Thank you for using MeetScheduler!</p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    logStep("Email response from Resend", { response: bookerEmailResponse });

    // Check if email sending failed
    if (bookerEmailResponse.error) {
      logStep("Email sending FAILED", { error: bookerEmailResponse.error });
      return new Response(
        JSON.stringify({ 
          success: false, 
          emailSent: false, 
          error: bookerEmailResponse.error.message,
          meetingLink 
        }),
        {
          status: 200, // Return 200 so booking isn't affected, but indicate email failed
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    logStep("Email sent successfully to booker");

    // Optionally send notification to host
    if (hostEmail) {
      const hostEmailResponse = await resend.emails.send({
        from: "MeetScheduler <onboarding@resend.dev>",
        to: [hostEmail],
        subject: `New Booking: ${meetingTitle} with ${bookerName}`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .header { background: linear-gradient(135deg, #10B981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
              .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
              .meeting-details { background: white; padding: 20px; border-radius: 8px; border: 1px solid #e5e7eb; margin: 20px 0; }
              .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #f3f4f6; }
              .detail-row:last-child { border-bottom: none; }
              .detail-label { font-weight: 600; color: #6b7280; width: 120px; }
              .detail-value { color: #111827; }
              .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h1 style="margin: 0; font-size: 24px;">📅 New Meeting Booked!</h1>
              </div>
              <div class="content">
                <p>You have a new meeting scheduled!</p>
                
                <div class="meeting-details">
                  <div class="detail-row">
                    <span class="detail-label">Meeting:</span>
                    <span class="detail-value">${meetingTitle}</span>
                  </div>
                  <div class="detail-row">
                    <span class="detail-label">Guest:</span>
                    <span class="detail-value">${bookerName} (${bookerEmail})</span>
                  </div>
                  <div class="detail-row">
                    <span class="detail-label">Date:</span>
                    <span class="detail-value">${formattedDate}</span>
                  </div>
                  <div class="detail-row">
                    <span class="detail-label">Time:</span>
                    <span class="detail-value">${formattedTime}</span>
                  </div>
                  <div class="detail-row">
                    <span class="detail-label">Duration:</span>
                    <span class="detail-value">${duration} minutes</span>
                  </div>
                </div>
                
                <div class="footer">
                  <p>MeetScheduler</p>
                </div>
              </div>
            </div>
          </body>
          </html>
        `,
      });

      logStep("Email sent to host", { response: hostEmailResponse });
    }

    return new Response(JSON.stringify({ success: true, meetingLink }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    logStep("ERROR", { message: error.message, stack: error.stack });
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
});
