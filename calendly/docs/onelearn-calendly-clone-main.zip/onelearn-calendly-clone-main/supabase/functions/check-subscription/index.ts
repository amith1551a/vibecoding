
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    
    const { data: { user } } = await supabaseClient.auth.getUser(token);
    
    if (!user) {
      throw new Error('User not authenticated');
    }

    // Initialize Stripe
    const stripe = new (await import('https://esm.sh/stripe@14.21.0')).default(
      Deno.env.get('STRIPE_SECRET_KEY') as string,
      { apiVersion: '2023-10-16' }
    );

    // Get user's email
    const userEmail = user.email;

    if (!userEmail) {
      throw new Error('User email not found');
    }

    // Check if user has an active subscription in Stripe
    const customers = await stripe.customers.list({
      email: userEmail,
      limit: 1,
    });

    let subscriptionStatus = 'free';
    let subscriptionTier = null;

    if (customers.data.length > 0) {
      const customer = customers.data[0];
      const subscriptions = await stripe.subscriptions.list({
        customer: customer.id,
        status: 'active',
      });

      if (subscriptions.data.length > 0) {
        const subscription = subscriptions.data[0];
        const priceId = subscription.items.data[0].price.id;
        
        // Map price IDs to subscription tiers
        if (priceId === 'price_1Rvv7tAqz61VbZKnRymRWzrZ') {
          subscriptionTier = 'pro';
          subscriptionStatus = 'active';
        } else if (priceId === 'price_1Rvv9AAqz61VbZKn8RNmKwTH') {
          subscriptionTier = 'pro_plus';
          subscriptionStatus = 'active';
        }
      }
    }

    // Update or create subscriber record using email as the conflict resolution
    const { error: upsertError } = await supabaseClient
      .from('subscribers')
      .upsert({
        user_id: user.id,
        email: userEmail,
        subscribed: subscriptionStatus === 'active',
        subscription_tier: subscriptionTier,
        updated_at: new Date().toISOString(),
      }, {
        onConflict: 'email'
      });

    if (upsertError) {
      console.error('Error upserting subscriber:', upsertError);
      // Don't throw error here, just log it - still return subscription status
    }

    return new Response(JSON.stringify({
      subscriptionStatus,
      subscriptionTier,
      email: userEmail
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    console.error("Error checking subscription:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
