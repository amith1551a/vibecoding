
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CALENDLY-CHECK-SUBSCRIPTION] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Use the service role key to perform writes (upsert) in Supabase
  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    { auth: { persistSession: false } }
  );

  try {
    logStep("Function started");

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      logStep("No authorization header provided");
      throw new Error("No authorization header provided");
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError) {
      logStep("Authentication error", { error: userError.message });
      throw new Error(`Authentication error: ${userError.message}`);
    }
    
    const user = userData.user;
    if (!user?.email) {
      logStep("User not authenticated or email not available");
      throw new Error("User not authenticated or email not available");
    }
    
    logStep("User authenticated", { userId: user.id, email: user.email });

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Get price IDs from environment variables
    const proPriceId = Deno.env.get("STRIPE_PRO_PRICE_ID");
    const proPlusPriceId = Deno.env.get("STRIPE_PRO_PLUS_PRICE_ID");
    
    logStep("Price IDs from env", { proPriceId, proPlusPriceId });

    // Check if customer exists in Stripe
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    
    if (customers.data.length === 0) {
      logStep("No Stripe customer found, setting as unsubscribed");
      
      // Update subscriber record
      const { error: upsertError } = await supabaseClient
        .from('subscribers')
        .upsert({
          user_id: user.id,
          email: user.email,
          stripe_customer_id: null,
          subscribed: false,
          subscription_tier: null,
          subscription_end: null,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'email'
        });

      if (upsertError) {
        logStep("Error upserting subscriber", { error: upsertError });
      }

      return new Response(JSON.stringify({ 
        subscribed: false,
        subscriptionTier: null,
        subscriptionEnd: null
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    const customerId = customers.data[0].id;
    logStep("Found Stripe customer", { customerId });

    // Check for active subscriptions
    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      status: "active",
      limit: 10,
    });

    let subscriptionTier = null;
    let subscriptionEnd = null;
    let subscriptionId = null;
    
    if (subscriptions.data.length > 0) {
      const subscription = subscriptions.data[0];
      subscriptionId = subscription.id;
      subscriptionEnd = new Date(subscription.current_period_end * 1000).toISOString();
      
      // Determine tier based on price ID from environment variables
      const priceId = subscription.items.data[0].price.id;
      logStep("Subscription price ID", { priceId });
      
      if (priceId === proPriceId) {
        subscriptionTier = "pro";
      } else if (priceId === proPlusPriceId) {
        subscriptionTier = "pro_plus";
      } else {
        // Fallback: check if any subscription exists, default to pro
        subscriptionTier = "pro";
        logStep("Unknown price ID, defaulting to pro", { priceId });
      }
      
      logStep("Active subscription found", { 
        subscriptionId, 
        subscriptionTier, 
        endDate: subscriptionEnd 
      });
    } else {
      logStep("No active subscription found");
    }

    // Update or create subscriber record
    const { error: upsertError } = await supabaseClient
      .from('subscribers')
      .upsert({
        user_id: user.id,
        email: user.email,
        stripe_customer_id: customerId,
        subscribed: subscriptions.data.length > 0,
        subscription_tier: subscriptionTier,
        subscription_end: subscriptionEnd,
        updated_at: new Date().toISOString(),
      }, {
        onConflict: 'email'
      });

    if (upsertError) {
      logStep("Error upserting subscriber", { error: upsertError });
    }

    const result = {
      subscribed: subscriptions.data.length > 0,
      subscriptionTier,
      subscriptionEnd
    };

    logStep("Subscription check completed", result);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    logStep("ERROR", { message: error.message, stack: error.stack });
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
