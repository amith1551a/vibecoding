
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CALENDLY-CREATE-CHECKOUT] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");
    
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      logStep("No authorization header provided");
      throw new Error("No authorization header provided");
    }

    const token = authHeader.replace("Bearer ", "");
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;
    
    if (!user?.email) {
      logStep("User not authenticated");
      throw new Error("User not authenticated");
    }

    logStep("User authenticated", { userId: user.id, email: user.email });

    // Parse request body
    let planType: string;
    try {
      const body = await req.json();
      planType = body.planType;
      logStep("Plan type requested", { planType });
    } catch (error) {
      logStep("Error parsing request body", { error });
      throw new Error("Invalid request body");
    }
    
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Check if customer exists
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
      logStep("Existing customer found", { customerId });
    } else {
      logStep("No existing customer found");
    }

    // Price IDs for Calendly plans - UPDATE THESE WITH YOUR ACTUAL STRIPE PRICE IDs
    // Get these from Stripe Dashboard -> Products -> Select product -> Copy Price ID
    const priceIds = {
      pro: Deno.env.get("STRIPE_PRO_PRICE_ID") || "price_1Rvv7tAqz61VbZKnRymRWzrZ",
      pro_plus: Deno.env.get("STRIPE_PRO_PLUS_PRICE_ID") || "price_1Rvv9AAqz61VbZKn8RNmKwTH",
    };

    const priceId = priceIds[planType as keyof typeof priceIds];
    if (!priceId) {
      logStep("Invalid plan type", { planType, availablePlans: Object.keys(priceIds) });
      throw new Error("Invalid plan type");
    }

    logStep("Creating checkout session", { priceId, planType });

    // Get the origin from the request
    const origin = req.headers.get("origin") || "https://cae6ebf8-3d24-4e75-8570-565906b8426f.sandbox.lovable.dev";
    logStep("Using origin", { origin });

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${origin}/?success=true&session_id={CHECKOUT_SESSION_ID}&plan=${planType}`,
      cancel_url: `${origin}/?canceled=true`,
      allow_promotion_codes: true,
    });

    logStep("Checkout session created successfully", { sessionId: session.id, url: session.url });

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    logStep("ERROR", { message: error.message, stack: error.stack });
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
